import java.sql.*;

public class Tester {

    public static void main(String[]args) throws Exception {
        DamiensDBConnector connection = new DamiensDBConnector();
    }
}
